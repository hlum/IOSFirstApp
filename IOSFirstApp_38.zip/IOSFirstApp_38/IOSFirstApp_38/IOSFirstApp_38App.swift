//
//  IOSFirstApp_38App.swift
//  IOSFirstApp_38
//
//  Created by Hlwan Aung Phyo on 2024/05/02.
//

import SwiftUI

@main
struct IOSFirstApp_38App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
