//
//  JyankenAPPApp.swift
//  JyankenAPP
//
//  Created by Hlwan Aung Phyo on 2024/05/31.
//

import SwiftUI

@main
struct JyankenAPPApp: App {
    var body: some Scene {
        WindowGroup {
                ContentView()
            }
        }
    
}
