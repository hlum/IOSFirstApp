//
//  CalculatorApp_24CM0138App.swift
//  CalculatorApp_24CM0138
//
//  Created by Hlwan Aung Phyo on 2024/06/10.
//

import SwiftUI

@main
struct CalculatorApp_24CM0138App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
